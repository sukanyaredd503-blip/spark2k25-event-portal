
import { motion } from "framer-motion";
import { Music, Zap } from "lucide-react";

const DJNight = () => {
    return (
        <section id="dj-night" className="relative py-20 overflow-hidden bg-black">
            {/* Background Animations */}
            <div className="absolute inset-0 z-0">
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-purple-600/20 rounded-full blur-[120px] animate-pulse" />
                <div className="absolute top-1/4 right-1/4 w-[400px] h-[400px] bg-blue-600/20 rounded-full blur-[100px] animate-pulse delay-700" />
            </div>

            <div className="container mx-auto px-4 relative z-10">
                <div className="flex flex-col items-center mb-16">
                    <motion.div
                        initial={{ opacity: 0, scale: 0.5 }}
                        whileInView={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.5 }}
                        className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-purple-500/10 border border-purple-500/30 mb-6"
                    >
                        <Zap className="w-4 h-4 text-purple-400 animate-pulse" />
                        <span className="text-sm font-orbitron font-bold text-purple-400 uppercase tracking-widest">Electric Vibes</span>
                    </motion.div>

                    <motion.h2
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        className="text-5xl md:text-7xl font-orbitron font-bold text-center mb-6 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-pink-500 to-blue-500"
                    >
                        DJ NIGHT
                    </motion.h2>
                    <p className="text-xl text-gray-400 font-exo max-w-2xl text-center">
                        Experience the ultimate neon-drenched musical journey with our headline DJ spinning the hottest tracks.
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                    <motion.div
                        initial={{ opacity: 0, x: -50 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        className="relative rounded-3xl overflow-hidden aspect-video border-2 border-purple-500/30 shadow-[0_0_50px_rgba(168,85,247,0.2)]"
                    >
                        <img
                            src="https://images.unsplash.com/photo-1571266028243-3716f02d2074?q=80&w=2072&auto=format&fit=crop"
                            alt="DJ Performance"
                            className="w-full h-full object-cover transform transition-transform duration-700 hover:scale-110"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
                        <div className="absolute bottom-6 left-6">
                            <h3 className="text-2xl font-orbitron font-bold text-white">Headline Act</h3>
                            <p className="text-purple-400 font-exo">10:00 PM - Midnight</p>
                        </div>
                    </motion.div>

                    <div className="space-y-8">
                        {[
                            { title: "Neon Pulse", desc: "Immersive light show synchronized with every beat." },
                            { title: "Bass Drop", desc: "High-fidelity sound systems for a bone-rattling experience." },
                            { title: "Interactive Crowd", desc: "Live VJing and crowd-integrated visual effects." }
                        ].map((item, i) => (
                            <motion.div
                                key={i}
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                transition={{ delay: i * 0.1 }}
                                className="flex gap-6 p-6 rounded-2xl bg-white/5 border border-white/10 hover:border-purple-500/50 transition-colors group"
                            >
                                <div className="w-12 h-12 rounded-xl bg-purple-500/20 flex items-center justify-center group-hover:bg-purple-500/40 transition-colors">
                                    <Music className="w-6 h-6 text-purple-400" />
                                </div>
                                <div>
                                    <h4 className="text-xl font-orbitron font-bold text-white mb-2">{item.title}</h4>
                                    <p className="text-gray-400 font-exo">{item.desc}</p>
                                </div>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </div>
        </section>
    );
};

export default DJNight;
