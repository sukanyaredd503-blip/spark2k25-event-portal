
import { motion } from "framer-motion";
import { Mic2, Users } from "lucide-react";

const MusicBand = () => {
    return (
        <section id="music-band" className="relative py-20 overflow-hidden bg-zinc-950">
            {/* Background Texture */}
            <div className="absolute inset-0 opacity-[0.03] bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]" />

            <div className="container mx-auto px-4 relative z-10">
                <div className="flex flex-col items-center mb-16 text-center">
                    <motion.div
                        initial={{ opacity: 0, scale: 0.5 }}
                        whileInView={{ opacity: 1, scale: 1 }}
                        className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-orange-500/10 border border-orange-500/30 mb-6"
                    >
                        <Mic2 className="w-4 h-4 text-orange-400" />
                        <span className="text-sm font-orbitron font-bold text-orange-400 uppercase tracking-widest">Live Performance</span>
                    </motion.div>

                    <motion.h2
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        className="text-5xl md:text-7xl font-orbitron font-bold mb-6 text-white"
                    >
                        MUSIC <span className="text-orange-500">BAND</span>
                    </motion.h2>
                    <p className="text-xl text-gray-400 font-exo max-w-2xl">
                        Unplugged vibes and rock anthems. Get ready for an evening of soulful melodies and high-octane live music.
                    </p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {[
                        {
                            name: "Echoes of Silence",
                            genre: "Alternative Rock",
                            time: "07:00 PM",
                            img: "https://images.unsplash.com/photo-1501386761578-eac5c94b800a?q=80&w=2070&auto=format&fit=crop"
                        },
                        {
                            name: "Sonic Fusion",
                            genre: "Indie Pop",
                            time: "08:30 PM",
                            img: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?q=80&w=2070&auto=format&fit=crop"
                        },
                        {
                            name: "The Rhythm Project",
                            genre: "Fusion Jazz",
                            time: "06:00 PM",
                            img: "https://images.unsplash.com/photo-1459749411177-042180ce673c?q=80&w=2070&auto=format&fit=crop"
                        }
                    ].map((band, i) => (
                        <motion.div
                            key={i}
                            initial={{ opacity: 0, y: 30 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            transition={{ delay: i * 0.2 }}
                            className="group relative rounded-3xl overflow-hidden aspect-[3/4] border border-white/10 hover:border-orange-500/50 transition-all duration-500"
                        >
                            <img src={band.img} alt={band.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />

                            <div className="absolute inset-0 p-8 flex flex-col justify-end transform translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
                                <div className="flex items-center gap-2 mb-2">
                                    <span className="px-3 py-1 rounded-full bg-orange-500 text-black text-xs font-bold uppercase">{band.genre}</span>
                                    <span className="text-white/60 text-sm font-exo">{band.time}</span>
                                </div>
                                <h3 className="text-3xl font-orbitron font-bold text-white mb-2">{band.name}</h3>
                                <div className="flex items-center gap-2 text-orange-400 opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-100">
                                    <Users size={16} />
                                    <span className="text-sm font-exo">Live on Main Stage</span>
                                </div>
                            </div>
                        </motion.div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default MusicBand;
