
import { motion } from "motion/react";
import { Mail, Linkedin, Twitter } from "lucide-react";

const organizers = [
    {
        name: "Dr. Rajesh Kumar",
        role: "Faculty Coordinator",
        department: "Computer Science",
        image: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=1974&auto=format&fit=crop",
    },
    {
        name: "Ananya Mehta",
        role: "Student Chairperson",
        department: "Information Technology",
        image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=1976&auto=format&fit=crop",
    },
    {
        name: "Vikram Singh",
        role: "Technical Head",
        department: "Mechanical Engineering",
        image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=2070&auto=format&fit=crop",
    },
    {
        name: "Sanya Malhotra",
        role: "Event Coordinator",
        department: "Electronics & Communication",
        image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=1961&auto=format&fit=crop",
    },
    {
        name: "Arjun Reddy",
        role: "Logistics Head",
        department: "Civil Engineering",
        image: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?q=80&w=1974&auto=format&fit=crop",
    },
    {
        name: "Priyanka Das",
        role: "Marketing Head",
        department: "MBA",
        image: "https://images.unsplash.com/photo-1567532939604-b6b5b0db2604?q=80&w=1974&auto=format&fit=crop",
    },
];

const Organizers = () => {
    return (
        <section id="organizers" className="py-20 relative overflow-hidden bg-background">
            {/* Background Decorations */}
            <div className="absolute top-0 right-0 w-1/2 h-1/2 bg-primary/5 blur-[120px] rounded-full -translate-y-1/2 translate-x-1/2" />
            <div className="absolute bottom-0 left-0 w-1/2 h-1/2 bg-secondary/5 blur-[120px] rounded-full translate-y-1/2 -translate-x-1/2" />

            <div className="container mx-auto px-4 relative z-10">
                <div className="text-center mb-16">
                    <motion.div
                        initial={{ opacity: 0, scale: 0.8 }}
                        whileInView={{ opacity: 1, scale: 1 }}
                        className="inline-block px-4 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-primary font-orbitron text-xs font-bold uppercase tracking-widest mb-4"
                    >
                        The Architects
                    </motion.div>
                    <motion.h2
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        className="text-4xl md:text-6xl font-orbitron font-bold mb-6 text-white"
                    >
                        MEET THE <span className="text-primary text-glow-orange">ORGANIZERS</span>
                    </motion.h2>
                    <p className="text-gray-400 font-exo max-w-2xl mx-auto text-lg leading-relaxed">
                        Dedicated team working tirelessly to bring SPARK 2K25 to life.
                        Committed to delivering an unforgettable experience.
                    </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10">
                    {organizers.map((member, index) => (
                        <motion.div
                            key={index}
                            initial={{ opacity: 0, y: 30 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ delay: index * 0.1 }}
                            className="group relative"
                        >
                            <div className="relative z-10 bg-card/40 backdrop-blur-sm border border-white/10 rounded-3xl overflow-hidden hover:border-primary/40 transition-all duration-500 hover:shadow-[0_20px_40px_-15px_rgba(255,107,0,0.15)]">
                                <div className="aspect-[4/5] relative overflow-hidden">
                                    <img
                                        src={member.image}
                                        alt={member.name}
                                        className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 group-hover:scale-105"
                                    />
                                    <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent opacity-60" />
                                </div>

                                <div className="p-8 text-center relative">
                                    {/* Accent line */}
                                    <div className="absolute top-0 left-1/2 -translate-x-1/2 w-12 h-1 bg-primary transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 rounded-full" />

                                    <h3 className="text-2xl font-orbitron font-bold text-white mb-1 group-hover:text-primary transition-colors">{member.name}</h3>
                                    <p className="text-primary font-exo text-sm font-semibold mb-2">{member.role}</p>
                                    <p className="text-gray-500 font-exo text-xs uppercase tracking-widest">{member.department}</p>

                                    <div className="flex justify-center gap-5 mt-6 opacity-0 translate-y-4 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-500">
                                        <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:bg-primary hover:text-white transition-all">
                                            <Linkedin size={18} />
                                        </a>
                                        <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:bg-primary hover:text-white transition-all">
                                            <Twitter size={18} />
                                        </a>
                                        <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:bg-primary hover:text-white transition-all">
                                            <Mail size={18} />
                                        </a>
                                    </div>
                                </div>
                            </div>

                            {/* Decorative background shape */}
                            <div className="absolute -inset-1 bg-gradient-to-r from-primary to-secondary opacity-0 group-hover:opacity-10 blur-2xl transition-opacity duration-500 -z-10 rounded-[40px]" />
                        </motion.div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Organizers;
