import { motion } from "motion/react";

const ScrollAnimation = () => {
  return (
    <motion.div
      whileInView={{ opacity: 1, y: 0 }}
      initial={{ opacity: 0, y: 60 }}
      transition={{ duration: 0.7 }}
      viewport={{ once: true }}
      className="h-40 bg-purple-500 text-white flex items-center justify-center"
    >
      Scroll to View
    </motion.div>
  );
};

export default ScrollAnimation;
