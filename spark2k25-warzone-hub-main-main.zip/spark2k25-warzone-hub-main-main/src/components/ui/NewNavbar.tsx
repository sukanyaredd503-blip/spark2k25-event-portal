import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import sparkLogo from "@/assets/spark-logo.png";

const NewNavbar = () => {
    const [isOpen, setIsOpen] = useState(false);
    const [scrolled, setScrolled] = useState(false);
    const navigate = useNavigate();
    const location = useLocation();

    useEffect(() => {
        const handleScroll = () => {
            setScrolled(window.scrollY > 50);
        };
        window.addEventListener("scroll", handleScroll);
        return () => window.removeEventListener("scroll", handleScroll);
    }, []);

    const scrollToSection = (id: string) => {
        if (id === "gallary-page" || id === "newgallary-page") {
            navigate("/gallary");
            setIsOpen(false);
            return;
        }

        if (id === "proshow-page") {
            navigate("/proshow");
            setIsOpen(false);
            return;
        }

        if (id === "teampage") {
            navigate("/team");
            setIsOpen(false);
            return;
        }

        if (id === "events-page") {
            navigate("/events");
            setIsOpen(false);
            return;
        }

        if (id === "highlights-page") {
            navigate("/highlights");
            setIsOpen(false);
            return;
        }

        if (id === "home") {
            navigate("/");
            setIsOpen(false);
            return;
        }

        const element = document.getElementById(id);
        if (element) {
            element.scrollIntoView({ behavior: "smooth" });
        } else if (location.pathname !== "/") {
            navigate("/");
            setTimeout(() => {
                const el = document.getElementById(id);
                el?.scrollIntoView({ behavior: "smooth" });
            }, 100);
        }
        setIsOpen(false);
    };

    const isGalleryPage = location.pathname === "/gallary";
    const isProshowPage = location.pathname === "/proshow";
    const isTeamPage = location.pathname === "/team";

    const navLinks = (isGalleryPage || isProshowPage || isTeamPage) ? [
        { name: "newGallery", id: "newgallary-page" },
        { name: "proshow", id: "proshow-page" },
        { name: "team", id: "teampage" },
        { name: "home", id: "home" },
    ] : [
        { name: "newGallery", id: "newgallary-page" },
        { name: "proshow", id: "proshow-page" },
        { name: "team", id: "teampage" },
        { name: "home", id: "home" },
    ];

    const getLinkClass = (id: string) => {
        const active =
            (id === "home" && location.pathname === "/") ||
            (id === "gallary-page" && location.pathname === "/gallary") ||
            (id === "newgallary" && location.pathname === "/gallary") || // Handle potential naming mismatch if any
            (id === "newgallary-page" && location.pathname === "/gallary") ||
            (id === "proshow-page" && location.pathname === "/proshow") ||
            (id === "teampage" && location.pathname === "/team") ||
            (id === "events-page" && location.pathname === "/events") ||
            (id === "highlights-page" && location.pathname === "/highlights");

        return active ? "text-pink-500 hover:text-pink-400 border-2 border-cyan-500" : "text-cyan-500 hover:text-cyan-400 border-2 border-transparent";
    };

    return (
        <nav
            className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled
                ? "bg-background/95 backdrop-blur-md border-b border-border shadow-lg"
                : "bg-transparent"
                }`}
        >
            <div className="container mx-auto px-4">
                <div className="flex items-center justify-between h-20">
                    <div
                        className="flex items-center gap-3 cursor-pointer group"
                        onClick={() => scrollToSection("home")}
                    >
                        <img
                            src={sparkLogo}
                            alt="SPARK 2K25"
                            className="h-12 w-12 transition-transform duration-300 group-hover:scale-110 group-hover:rotate-12"
                        />
                        <span className="text-2xl font-orbitron font-bold text-glow-cyan">
                            SPARK <span className="text-primary">2K25</span>
                        </span>
                    </div>

                    {/* Desktop Navigation */}
                    <div className="hidden md:flex items-center gap-1">
                        {navLinks.map((link) => (
                            <Button
                                key={link.id}
                                variant="ghost_glow"
                                onClick={() => scrollToSection(link.id)}
                                className={`font-orbitron ${getLinkClass(link.id)}`}
                            >
                                {link.name}
                            </Button>
                        ))}
                    </div>

                    {/* Mobile Menu Toggle */}
                    <button
                        className="md:hidden text-foreground hover:text-accent transition-colors"
                        onClick={() => setIsOpen(!isOpen)}
                    >
                        {isOpen ? <X size={28} /> : <Menu size={28} />}
                    </button>
                </div>

                {/* Mobile Navigation */}
                {isOpen && (
                    <div className="md:hidden pb-4 animate-slide-up">
                        <div className="flex flex-col gap-2">
                            {navLinks.map((link) => (
                                <Button
                                    key={link.id}
                                    variant="ghost_glow"
                                    onClick={() => scrollToSection(link.id)}
                                    className={`w-full justify-start font-orbitron ${getLinkClass(link.id)}`}
                                >
                                    {link.name}
                                </Button>
                            ))}
                        </div>
                    </div>
                )}
            </div>
        </nav>
    );
};

export default NewNavbar;
