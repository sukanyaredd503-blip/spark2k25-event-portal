
import { motion } from 'framer-motion';

interface GalleryNavProps {
    activeTab: string;
    onTabChange: (tab: string) => void;
}

const GalleryNav = ({ activeTab, onTabChange }: GalleryNavProps) => {
    const tabs = [
        { id: 'gallery', label: 'Gallery' },
        { id: 'proshow', label: 'Proshow' },
        { id: 'team', label: 'Team' },
    ];

    return (
        <div className="flex justify-center items-center py-8 z-20 relative">
            <div className="flex space-x-2 md:space-x-4 bg-background/50 backdrop-blur-md p-2 rounded-full border border-white/10 shadow-lg">
                {tabs.map((tab) => (
                    <button
                        key={tab.id}
                        onClick={() => onTabChange(tab.id)}
                        className={`relative px-4 md:px-6 py-2 rounded-full text-sm md:text-base font-orbitron transition-all duration-300 ${activeTab === tab.id
                            ? 'text-white'
                            : 'text-gray-400 hover:text-white'
                            }`}
                    >
                        {activeTab === tab.id && (
                            <motion.div
                                layoutId="activeTab"
                                className="absolute inset-0 bg-gradient-to-r from-orange-600 to-red-600 rounded-full"
                                initial={false}
                                transition={{ type: "spring", stiffness: 500, damping: 30 }}
                                style={{ zIndex: -1 }}
                            />
                        )}
                        <span className="relative z-10">{tab.label}</span>
                    </button>
                ))}
            </div>
        </div>
    );
};

export default GalleryNav;
