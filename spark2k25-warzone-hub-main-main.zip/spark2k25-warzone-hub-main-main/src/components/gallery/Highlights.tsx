import { motion } from "framer-motion";
const Highlights = () => {
    const images = [
        
    ];

    return (
        <div id="highlights" className="max-w-7xl mx-auto px-4 py-8">
            <div className="columns-1 md:columns-2 lg:columns-3 gap-8 space-y-8">
                {images.map((img, index) => (
                    <motion.div
                        key={index}
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: index * 0.1 }}
                        className="break-inside-avoid rounded-xl overflow-hidden border border-white/5 hover:border-blue-500/30 transition-all duration-300 relative group"
                    >
                        <img src={img} alt={`Highlight ${index}`} className="w-full h-auto object-cover transform transition-transform duration-700 group-hover:scale-105" />
                        <div className="absolute inset-0 bg-blue-900/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center backdrop-blur-[2px]">
                            <div className="text-white font-orbitron text-xs tracking-widest uppercase py-2 px-4 border border-white/20 rounded-lg">
                                View
                            </div>
                        </div>
                    </motion.div>
                ))}
            </div>
            <motion.h2
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-4xl md:text-5xl font-orbitron font-bold text-left mt-16 text-pink-500"
            >
            </motion.h2>
        </div>
    );
};

export default Highlights;
