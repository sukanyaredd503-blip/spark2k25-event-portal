
import { motion } from "framer-motion";

const Spotlights = () => {
    // Placeholder data
    const items = [
        { id: 1, title: "Grand Opening", image: "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?q=80&w=2070&auto=format&fit=crop" },
        { id: 2, title: "Keynote Speech", image: "https://images.unsplash.com/photo-1544531586-fde5298cdd40?q=80&w=2070&auto=format&fit=crop" },
        { id: 3, title: "Award Ceremony", image: "https://images.unsplash.com/photo-1531297461136-82lw9z3l0v9m?q=80&w=2070&auto=format&fit=crop" },
    ];

    return (
        <div className="max-w-7xl mx-auto px-4 py-8">
            <motion.h2
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-3xl md:text-4xl font-orbitron font-bold text-center mb-12 text-glow-orange"
            >
                EVENT SPOTLIGHTS
            </motion.h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {items.map((item, index) => (
                    <motion.div
                        key={item.id}
                        initial={{ opacity: 0, y: 30 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.2 }}
                        className="group relative aspect-[4/3] rounded-xl overflow-hidden border border-white/10 hover:border-primary/50 transition-all duration-300 shadow-lg hover:shadow-primary/20"
                    >
                        <div className="absolute inset-0 bg-gray-900">
                            {/* Replace with actual image later */}
                            <img src={item.image} alt={item.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                        </div>
                        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent flex flex-col justify-end p-6 translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                            <h3 className="text-xl font-orbitron font-bold text-white group-hover:text-primary transition-colors">{item.title}</h3>
                            <div className="w-12 h-1 bg-primary mt-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                        </div>
                    </motion.div>
                ))}
            </div>
        </div>
    );
};

export default Spotlights;
