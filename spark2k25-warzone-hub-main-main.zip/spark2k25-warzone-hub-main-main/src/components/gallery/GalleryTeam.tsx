import { motion } from "framer-motion";
import { Github, Linkedin, Twitter } from "lucide-react";

const team = [
    {
        name: "Alex Rivera",
        role: "Event Head",
        image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=1974&auto=format&fit=crop",
    },
    {
        name: "Sarah Chen",
        role: "Technical Lead",
        image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=1974&auto=format&fit=crop",
    },
    {
        name: "Marcus Thorne",
        role: "Creative Director",
        image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=1974&auto=format&fit=crop",
    },
    {
        name: "Elena Rodriguez",
        role: "Marketing Head",
        image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?q=80&w=1974&auto=format&fit=crop",
    },
];

const GalleryTeam = () => {
    return (
        <div id="gallery-team" className="max-w-7xl mx-auto px-4 py-16">
            <motion.h2
                initial={{ opacity: 0, y: -20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="text-4xl md:text-5xl font-orbitron font-bold text-left mb-16 text-white"
            >
                BTS
            </motion.h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                {team.map((member, index) => (
                    <motion.div
                        key={index}
                        initial={{ opacity: 0, y: 30 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: index * 0.1 }}
                        className="group relative h-96 rounded-xl overflow-hidden bg-zinc-900 border border-white/5 transition-all duration-300 hover:border-blue-500/30"
                    >
                        <img
                            src={member.image}
                            alt={member.name}
                            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 opacity-80 group-hover:opacity-100"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent flex flex-col justify-end p-6">
                            <h3 className="text-xl font-orbitron font-bold text-white tracking-tight">{member.name}</h3>
                            <p className="text-blue-400 font-exo text-xs font-bold tracking-widest uppercase mt-1">{member.role}</p>

                            <div className="flex gap-4 mt-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                                <Linkedin size={16} className="text-gray-400 hover:text-blue-400 cursor-pointer transition-colors" />
                                <Twitter size={16} className="text-gray-400 hover:text-blue-400 cursor-pointer transition-colors" />
                            </div>
                        </div>
                    </motion.div>
                ))}
            </div>
        </div>
    );
};

export default GalleryTeam;
