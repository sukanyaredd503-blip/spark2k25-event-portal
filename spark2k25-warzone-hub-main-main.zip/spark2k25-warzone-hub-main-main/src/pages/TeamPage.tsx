
import NewNavbar from "@/components/ui/NewNavbar";
import Footer from "@/components/Footer";
import Organizers from "@/components/team/Organizers";
import Gallarys from "@/components/ui/gallaryimage";
import { ThreeDPhotoCarousel } from "@/components/ui/circular";
import { BeamsBackground } from "@/components/ui/beams";

const teamImages = [
    {
        src: "https://images.unsplash.com/photo-1511268559489-34b624fbfcf5?auto=format&fit=crop&q=80&w=800",
        alt: "Stage Crew",
    },
    {
        src: "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&q=80&w=800",
        alt: "Event Coordinator",
    },
    {
        src: "https://images.unsplash.com/photo-1511268559489-34b624fbfcf5?auto=format&fit=crop&q=80&w=800",
        alt: "Lead Photographer",
    },
    {
        src: "https://images.unsplash.com/photo-1514525253440-b393452e23f9?auto=format&fit=crop&q=80&w=800",
        alt: "Sound Engineer",
    },
];

const TeamPage = () => {
    return (
        <div className="min-h-screen bg-background text-foreground relative overflow-x-hidden">
            <BeamsBackground className="fixed inset-0 z-0 pointer-events-none" />

            <div className="relative z-10">
                <NewNavbar />
                <div className="pt-20">
                    <section className="relative">
                    </section>

                    <section className="py-20">
                        <ThreeDPhotoCarousel images={teamImages.map(img => img.src)} />
                    </section>

                    <section>
                        <Organizers />
                    </section>
                    <section className="container mx-auto px-4 py-16">
                        <h2 className="text-3xl font-bold text-center mb-8 text-white">Team Gallery</h2>
                        <Gallarys images={teamImages.map(img => img.src)} />
                    </section>
                </div>
                <Footer className="bg-black" />
            </div>
        </div>
    );
};

export default TeamPage;
