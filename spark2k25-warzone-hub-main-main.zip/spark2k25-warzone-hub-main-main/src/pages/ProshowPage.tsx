
import NewNavbar from "@/components/ui/NewNavbar";
import Footer from "@/components/Footer";
import FireParticles from "@/components/FireParticles";
import DJNight from "@/components/proshow/DJNight";
import MusicBand from "@/components/proshow/MusicBand";

const ProshowPage = () => {
    return (
        <div className="min-h-screen bg-background text-foreground relative overflow-x-hidden">
            <FireParticles density={60} />
            <NewNavbar />
            <div className="pt-20">
                <DJNight />
                <MusicBand />
            </div>
            <Footer />
        </div>
    );
};

export default ProshowPage;
