import { ChevronDown } from "lucide-react";
import { motion } from "framer-motion";
import FireParticles from "@/components/FireParticles";
import NewNavbar from "@/components/ui/NewNavbar";
const HighlightPage = () => {
    return (
        <div className="min-h-screen bg-black text-white relative overflow-x-hidden font-exo">
            {/* Simple Dynamic Background */}
            <div className="fixed inset-0 pointer-events-none z-0">
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[600px] bg-blue-600/10 blur-[150px] rounded-full" />
                <div className="absolute bottom-0 right-0 w-[400px] h-[400px] bg-blue-900/10 blur-[120px] rounded-full" />
            </div>

            <NewNavbar />
            <FireParticles density={30} />

            {/* Simple Hero Section */}
            <section className="relative min-h-[90vh] flex flex-col items-center justify-center px-4 pt-20 z-10">
                <motion.div
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                    className="relative z-10 text-center space-y-6 max-w-4xl mx-auto"
                >
                    <span className="text-blue-400 font-orbitron text-xs tracking-[0.5em] uppercase px-4 py-1 border border-blue-500/20 rounded-full bg-blue-500/5">
                        Moments in Motion
                    </span>

                    <h1 className="text-6xl md:text-8xl lg:text-9xl font-orbitron font-bold tracking-tight">
                        <span className="block text-white">SPARK</span>
                        <span className="block text-blue-600">HIGHLIGHTS</span>
                    </h1>

                    <p className="text-lg md:text-xl text-gray-400 font-exo max-w-2xl mx-auto leading-relaxed px-4">
                        A clean, dynamic archive of our greatest beats and biggest wins.
                        Relive the energy of Spark 2K26.
                    </p>

                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 0.5 }}
                        className="pt-10 flex flex-col items-center gap-4 cursor-pointer group"
                        onClick={() => document.getElementById('highlights-content')?.scrollIntoView({ behavior: 'smooth' })}
                    >
                        <span className="text-[10px] uppercase tracking-widest font-orbitron text-gray-500 group-hover:text-blue-400 transition-colors">
                            Scroll to Begin
                        </span>
                        <ChevronDown className="w-6 h-6 text-blue-500 animate-bounce" />
                    </motion.div>
                </motion.div>
            </section>

            {/* Dynamic Content Sections */}
            <div id="highlights-content" className="relative z-10 space-y-40 pb-20">
                <motion.div
                    initial={{ opacity: 0 }}
                    whileInView={{ opacity: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 1 }}
                >

                </motion.div>

                <motion.div
                    initial={{ opacity: 0 }}
                    whileInView={{ opacity: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 1 }}
                >

                </motion.div>

                <motion.div
                    initial={{ opacity: 0 }}
                    whileInView={{ opacity: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 1 }}
                >
                </motion.div>
            </div>

        </div>
    );
};

export default HighlightPage;
